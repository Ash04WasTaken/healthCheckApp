# author Manuel Malinov

from django.apps import AppConfig

# configuration for the team leader
class TeamleaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'teamleader'
