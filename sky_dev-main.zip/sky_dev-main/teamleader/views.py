# author griselle fernandes

from django.shortcuts import render

# Create your views here.

# to add or delete user
def adddeleteuser(request):
    return render(request, 'add_delete_user.html')
# to select cards
def cardselectadmin(request):
    return render(request, 'card_select_admin.html')
# to view card trend
def cardselecttrend(request):
    return render(request, 'card_select_trend.html')
# to view all the cards
def overallcardmanager(request):
    return render(request, 'overall_card_trend_manager.html')
# to get single card trend
def singlecardmanager(request):
    return render(request, 'single_card_trend_manager.html')
# for the leaders health check page
def leadermenupage(request):
    return render(request, 'teamleader_menu_page.html')


#from project template folder
def navbar(request):
    return render (request, 'navbar.html')

# to check if the team leader is a user
def is_team_leader(user):
    return user.is_staff  


