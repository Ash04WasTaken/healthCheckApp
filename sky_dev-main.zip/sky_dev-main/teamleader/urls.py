# author griselle fernandes 
from django.urls import path
from.import views

urlpatterns = [
    # adding or deleting users
    path('adddeleteuser', views.adddeleteuser, name='adddeleteuser'),
    # card selection
    path('cardselectadmin', views.cardselectadmin, name='cardselectadmin'),
    # card trend view
    path('cardselecttrend', views.cardselecttrend, name='cardselecttrend'),
    # viewing all the cards
    path('overallcardmanager', views.overallcardmanager, name='overallcardmanager'),
    # viewing signle cards
    path('singlecardmanager', views.singlecardmanager, name='singlecardmanager'),
    # leader health check page
    path('leadermenupage', views.leadermenupage, name='leadermenupage'),
    

]