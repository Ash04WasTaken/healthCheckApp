# author Manuel Malinov


from django.contrib import admin
from .models import DeliveringValue

# Registers the DeliveringValue model with the Django admin site for management through the admin interface.
admin.site.register(DeliveringValue)
