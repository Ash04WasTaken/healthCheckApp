# author Manuel Malinov


from django.db import models
from django.contrib.auth.models import User
from django.shortcuts import render

# this is for getting and storing the user input for the health check page
class DeliveringValue(models.Model):
    # this is for the colour choices
    COLOR_CHOICES = [
        ('red-stable', 'Red - Stable'),
        ('red-improving', 'Red - Improving'),
        ('red-worse', 'Red - Getting Worse'),
        ('yellow-stable', 'Yellow - Stable'),
        ('yellow-improving', 'Yellow - Improving'),
        ('yellow-worse', 'Yellow - Getting Worse'),
        ('green-stable', 'Green - Stable'),
        ('green-improving', 'Green - Improving'),
        ('green-worse', 'Green - Getting Worse'),
    ]

    # this is to record the username
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    # this is to record the user choosen colour status
    color_status = models.CharField(max_length=20, choices=COLOR_CHOICES)
    # this is to record the user input 
    reason = models.TextField()
 # this is to record the user input 

    improvement = models.TextField()
    # stores all the values in the database and checks if everything is filled
    submitted_at = models.DateTimeField(auto_now_add=True)

# creates instance of the delivering values so that the user can see their votes for that session
    def __str__(self):
        return self.user.username

# to view all their votes till now (only for the user logged in)
def view_answers(request):
    submissions = DeliveringValue.objects.filter(user=request.user).order_by('-submitted_at')
    return render(request, 'view_answers.html', {'submissions': submissions})