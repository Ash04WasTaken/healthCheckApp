# author griselle fernandes

# here are all the url to the html pages

from django.urls import path
from.import views

urlpatterns = [
    # this is the default page
    path('', views.welcome, name='home'),
    # profile page
    path('profile', views.profile, name='profile'),
    # logout page
    path('logoutmessage/', views.logoutmessage, name='logoutmessage'),
    # menu page
    path('menupage/', views.menupage, name='menupage'),
    # summary page
    path('summaryselection/', views.summaryselection, name='summaryselection'),
    # viewing trend page
    path('trendselection/', views.trendselection, name='trendselection'),
    # viewing line graph    
    path('linechart/', views.linechart, name='linechart'),
    # viewing pie graph
    path('piechart/', views.piechart, name='piechart'),
    # viewing the overall trend
    path('overallcard/', views.overallcard, name='overallcard'),
    # viewing single card page
    path('singlecard/', views.singlecard, name='singlecard'),
# password chaning page
    path('passwordchange/', views.passwordchange, name='passwordchange'),
# delivering value page
    path('delivering-value/', views.delivering_value_view, name='delivering_value'),
    # deliver value confirmation page
    path('delivering-value/confirm/', views.confirm_submission, name='confirm_submission'),
    # deliving value view page
    path('delivering-value/view/', views.view_submission, name='view_submission'),
    

    #   path('delivering-value/', views.delivering_value_view, name='deliveringvalue'),
    # path('easy-to-release/', views.easy_to_release_view, name='easytorelease'),


# votes view page
    path('view-answers/', views.view_submission, name='view_submission'),
# team overview page
    path('health/team-overview/', views.team_overview, name='team_overview'),

]