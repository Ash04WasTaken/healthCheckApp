# author Manuel Malinov


from django import forms
from .models import DeliveringValue

# to create field based on the values
class DeliveringValueForm(forms.ModelForm):
    class Meta:
        # specifies the model
        model = DeliveringValue
        # the fields to be included in the form
        fields = ['color_status', 'reason', 'improvement']
