# author griselle fernandes

from django.shortcuts import render
from django.shortcuts import render, redirect
from .forms import DeliveringValueForm
from .models import DeliveringValue
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from collections import Counter




# Create your views here.

# views for the health check page
def welcome(request):
    return render(request, 'health_check/welcome_to_healthcheck_page.html')
# views for the profile page
def profile(request):
    return render(request, 'health_check/edit_details_page.html')
# views for the logout page
def logoutmessage(request):
    return render(request, 'health_check/log_out_message_page.html')
# views for the menu page
def menupage(request):
    return render(request, 'health_check/user_menu_page.html')
# views for the summary selection page
def summaryselection(request):
    return render(request, 'health_check/user_summary_selection_page.html')
# views for the trends page
def trendselection(request):
    return render(request, 'health_check/view_trends_page.html')
# views for the line chart page
def linechart(request):
    return render(request, 'health_check/user_linechart.html')
# views for the pie chart page
def piechart(request):
    return render(request, 'health_check/user_piechart.html')
# views for the overall card page
def overallcard(request):
    return render(request, 'health_check/overall_cards_trend.html')
# views for the single card page
def singlecard(request):
    return render(request, 'health_check/single_card_trends.html')
# views for changing the password page
def passwordchange(request):
    return render(request, 'health_check/password_change_page.html')
#views from the nav bar page
def navbar(request):
    return render (request, 'navbar.html')

# checks if the user is logged in and only shows the trend if they are logged in to the system
#  this is used for the team leader, senion manager and department leader
@login_required
def delivering_value_view(request):
    if request.method == 'POST':
        form = DeliveringValueForm(request.POST)
        if form.is_valid():
            dv = form.save(commit=False)
            # Assign the current logged-in user
            dv.user = request.user  
            dv.save()
            # Set the session variable
            request.session['submitted'] = True  
            return redirect('confirm_submission')
    else:
        form = DeliveringValueForm()

    return render(request, 'health_check/userhealthcheck.html', {'form': form})

def confirm_submission(request):
    return render(request, 'health_check/confirm.html')


def view_submission(request):
    # Check if the user has submitted any data
    if request.session.get('submitted', False):
        # Fetch the latest submission for the user
        latest_submission = DeliveringValue.objects.filter(user=request.user).latest('submitted_at')
        
        # Fetch all submissions made by the logged-in user
        all_submissions = DeliveringValue.objects.filter(user=request.user).order_by('-submitted_at')
        
        # Render the page with the latest submission and all submissions
        return render(request, 'health_check/view_answers.html', {
            'latest_submission': latest_submission,
            'all_submissions': all_submissions
        })
    
    # Redirect to the 'delivering_value' page if the user hasn't submitted anything
    return redirect('delivering_value')

# checks if the user is a team leader
def is_team_leader(user):
    return user.is_staff 

#  to display the graph to the user
#  should be displayed before all the user votes cards 
@login_required
def team_overview(request):
    submissions = DeliveringValue.objects.all().order_by('-submitted_at')

    # Extract color parts (e.g., from 'red-improving' -> 'red')
    colors = [s.color_status.split('-')[0] for s in submissions]
    color_counts = Counter(colors)  # e.g., {'red': 5, 'yellow': 3, 'green': 2}

    return render(request, 'health_check/team_overview.html', {
        'submissions': submissions,
        'color_data': dict(color_counts),
    })