# author Manuel Malinov


from django.apps import AppConfig

# Configuration for the 'departmentleader' app with default auto field type and app name.
class DepartmentleaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'departmentleader'
