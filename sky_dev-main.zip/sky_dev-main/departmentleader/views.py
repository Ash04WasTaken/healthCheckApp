# author griselle fernandes

from django.shortcuts import render

# Create your views here.

# Renders the menu page for Department Leaders and Senior roles.
def DepSeniormenupage(request):
    return render(request, 'departmentAndSenior_menu_page.html')
