# author griselle fernandes

from django.urls import path
from.import views

urlpatterns = [
    # senior manageer page for health check
    path('DepSeniormenupage', views.DepSeniormenupage, name='DepSeniormenupage'),
]