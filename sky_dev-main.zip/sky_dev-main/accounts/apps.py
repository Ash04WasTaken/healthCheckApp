# author Manuel Malinov

from django.apps import AppConfig

# for the accounts and the fields
class AccountsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accounts'

def ready(self):
    import accounts.signals
