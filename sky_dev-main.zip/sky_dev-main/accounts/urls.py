# author griselle fernandes

from django.urls import path
from . import views

urlpatterns = [
    # signup page
    path('signupaccount/', views.signupaccount, name='signupaccount'),
    # logout of the account
    path('logout/', views.logoutaccount, name='logoutaccount'),
    # login page
    path('login/', views.loginaccount, name='loginaccount'),
]


