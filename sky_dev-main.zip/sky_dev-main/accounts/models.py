# author Manuel Malinov


from django.db import models
from django.contrib.auth.models import User

# stores which type of user they are 
class Profile(models.Model):
    ROLE_CHOICES = (
        ('Engineer', 'Engineer'),
        ('Department Leader', 'Department Leader'),
        ('Team Leader', 'Team Leader'),
        ('Senior Manager', 'Senior Manager'),
        ('Admin', 'Admin'),
    )

# when the user decides to delete the user
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # to select the role of the user when deleting
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)

# used for displaying the usernames
    def __str__(self):
        return self.user.username

