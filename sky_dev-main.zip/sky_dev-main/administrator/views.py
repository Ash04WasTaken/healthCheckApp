# author griselle fernandes

from django.shortcuts import render

# Create your views here.
# add user page
def adduserinfo(request):
    return render(request, 'add_user_information_page.html')
# admin page
def adminmainpage(request):
    return render(request, 'admin_main_page.html')
# add team page
def addteam(request):
    return render(request, 'add_team_page.html')
# add department page
def adddepartment(request):
    return render(request, 'add_department_page.html')
# add or delete users page
def adddeleteuser(request):
    return render(request, 'add_delete_users_table.html')
# add or delete team page
def adddeleteteam(request):
    return render(request, 'add_delete_teams_table.html')
# add or delete department page
def adddeletedepartment(request):
    return render(request, 'add_delete_department_table.html')
# add or delete card page
def adddeletecard(request):
    return render(request, 'add_delete_card_table.html')
# add card page
def addcard(request):
    return render(request, 'add_card_page.html')

