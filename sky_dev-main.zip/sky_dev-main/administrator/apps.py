# author Manuel Malinov


from django.apps import AppConfig

# Configuration class for the 'administrator' app, setting default auto field type and app name.
class AdministratorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'administrator'
