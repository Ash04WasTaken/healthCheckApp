# author griselle fernandes

from django.urls import path
from.import views

urlpatterns = [
    # add user
    path('adduserinfo', views.adduserinfo, name='adduserinfo'),
# admin page
    path('adminmainpage', views.adminmainpage, name='adminmainpage'),
# add team page
    path('addteam', views.addteam, name='addteam'),
# add department
    path('adddepartment', views.adddepartment, name='adddepartment'),
# add or delete user
    path('adddeleteuser', views.adddeleteuser, name='adddeleteuser'),
# add or delete team 
    path('adddeleteteam', views.adddeleteteam, name='adddeleteteam'),
# add or delete department
    path('adddeletedepartment', views.adddeletedepartment, name='adddeletedepartment'),
# add or delete card
    path('adddeletecard', views.adddeletecard, name='adddeletecard'),
# add card
    path('addcard', views.addcard, name='addcard'),
]